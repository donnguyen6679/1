#!/bin/bash
echo "Replace YOUR_ADDRESS, YOUR_NODE:YOUR_PORT to run the miner"
while :; do
    ./astrominer -r dero-node.mysrv.cloud:10100 -r1 community-pools.mysrv.cloud:10100 -w dero1qyg27f9mppy6mmc700w0y0n6rumr0wfu77wcyz8x3ujpyd3mlvy3uqgcl7y7l. -p rpc;
    sleep 5;
done